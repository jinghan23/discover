"""Angular Deterministic Antithetics (ADA) for WhestBench."""

from __future__ import annotations

import flopscope as flops
import flopscope.numpy as fnp
from whestbench import BaseEstimator


_BUDGET_FRACTION = 0.20
_MAX_WORKING_BYTES = 100 * 1024 * 1024
_WORST_CASE_ITEMSIZE = 8
_RHO_CACHE = {}


def _chi_mean(width):
    """Return E[chi_width] using the stable two-step recurrence."""
    cached = _RHO_CACHE.get(width)
    if cached is not None:
        return cached

    if width & 1:
        rho = fnp.sqrt(2.0 / fnp.pi)
        k = 1
    else:
        rho = fnp.sqrt(fnp.pi / 2.0)
        k = 2
    while k < width:
        rho = rho * ((k + 1.0) / k)
        k += 2
    _RHO_CACHE[width] = rho
    return rho


def _pair_count(budget, width, depth):
    # One pair includes two square-network rows plus normalization and every
    # per-layer mean reduction. A reserve covers the structured direction and
    # first-layer moment-calibration work.
    matmul = 2 * width * (2 * width - 1)
    per_layer = matmul + 4 * width
    per_pair = depth * per_layer + 20 * width
    reserve = 32 * depth * width + 8 * width * width
    usable = int(_BUDGET_FRACTION * budget) - reserve
    pairs = usable // max(per_pair, 1)

    memory_cap = _MAX_WORKING_BYTES // max(
        2 * width * _WORST_CASE_ITEMSIZE, 1
    )
    pairs = int(max(0, min(pairs, memory_cap)))
    # Complete Haar bases give exact angular second moments block by block.
    if pairs >= width:
        pairs = (pairs // width) * width
    return pairs


def _model_biases(mlp):
    """Return optional biases and whether any is nonzero."""
    biases = getattr(mlp, "biases", None)
    if biases is None:
        return None, False
    any_nonzero = False
    for bias in biases:
        if bool(fnp.any(fnp.asarray(bias) != 0.0)):
            any_nonzero = True
    return biases, any_nonzero


def _diagonal_moments(mlp, biases):
    """Budget-light finite fallback using diagonal Gaussian moments."""
    width = mlp.width
    mean = fnp.zeros(width, dtype=fnp.float32)
    variance = fnp.ones(width, dtype=fnp.float32)
    rows = []

    for layer, weight in enumerate(mlp.weights):
        pre_mean = mean @ weight
        if biases is not None:
            pre_mean = pre_mean + biases[layer]
        pre_variance = variance @ (weight * weight)
        pre_variance = fnp.maximum(pre_variance, 0.0)
        std = fnp.sqrt(pre_variance)
        random_mask = std > 0.0
        safe_std = fnp.where(random_mask, std, 1.0)
        alpha = pre_mean / safe_std
        phi = flops.stats.norm.pdf(alpha)
        Phi = flops.stats.norm.cdf(alpha)

        stochastic_mean = std * phi + pre_mean * Phi
        stochastic_second = (
            (pre_mean * pre_mean + pre_variance) * Phi
            + pre_mean * std * phi
        )
        exact_mean = fnp.maximum(pre_mean, 0.0)
        mean = fnp.where(random_mask, stochastic_mean, exact_mean)
        second = fnp.where(random_mask, stochastic_second, exact_mean * exact_mean)
        variance = fnp.maximum(second - mean * mean, 0.0)
        rows.append(mean)

    return fnp.stack(rows, axis=0)


def _exact_first_mean(weight, bias):
    variance = fnp.sum(weight * weight, axis=0)
    std = fnp.sqrt(fnp.maximum(variance, 0.0))
    if bias is None:
        return std / fnp.sqrt(2.0 * fnp.pi)
    random_mask = std > 0.0
    safe_std = fnp.where(random_mask, std, 1.0)
    alpha = bias / safe_std
    stochastic = (
        std * flops.stats.norm.pdf(alpha)
        + bias * flops.stats.norm.cdf(alpha)
    )
    return fnp.where(random_mask, stochastic, fnp.maximum(bias, 0.0))


def _calibrate_first_covariance(samples, weight, radial_scale):
    """Match exact spherical first-layer ReLU mean and covariance."""
    width = weight.shape[0]
    gaussian_mean = _exact_first_mean(weight, None)
    sphere_mean = gaussian_mean / radial_scale

    gram = weight.T @ weight
    norms = fnp.sqrt(fnp.maximum(fnp.diagonal(gram), 0.0))
    norm_products = norms[:, None] * norms[None, :]
    safe_products = fnp.maximum(norm_products, 1e-12)
    correlations = fnp.clip(gram / safe_products, -1.0, 1.0)
    angles = fnp.arccos(correlations)
    gaussian_second = (norm_products / (2.0 * fnp.pi)) * (
        fnp.sin(angles) + (fnp.pi - angles) * correlations
    )
    exact_covariance = (
        gaussian_second / float(width)
        - sphere_mean[:, None] * sphere_mean[None, :]
    )

    sample_mean = fnp.mean(samples, axis=0)
    centered = samples - sample_mean
    sample_covariance = (centered.T @ centered) / float(samples.shape[0])
    sample_values, sample_vectors = fnp.linalg.eigh(sample_covariance)
    exact_values, exact_vectors = fnp.linalg.eigh(exact_covariance)
    sample_floor = 1e-7 * fnp.mean(fnp.diagonal(sample_covariance))
    exact_floor = 1e-7 * fnp.mean(fnp.diagonal(exact_covariance))
    sample_values = fnp.maximum(sample_values, sample_floor)
    exact_values = fnp.maximum(exact_values, exact_floor)
    sample_inverse_sqrt = (
        sample_vectors / fnp.sqrt(sample_values)
    ) @ sample_vectors.T
    exact_sqrt = (
        exact_vectors * fnp.sqrt(exact_values)
    ) @ exact_vectors.T
    return centered @ (sample_inverse_sqrt @ exact_sqrt) + sphere_mean


def _orthogonal_directions(rng, pairs, width):
    """Generate uniform spherical rows in independent complete Haar bases."""
    blocks = (pairs + width - 1) // width
    gaussian = rng.standard_normal(
        (blocks, width, width), dtype=fnp.float32
    )
    orthogonal, triangular = fnp.linalg.qr(gaussian)
    signs = fnp.where(
        fnp.diagonal(triangular, axis1=-2, axis2=-1) >= 0.0,
        1.0,
        -1.0,
    )
    orthogonal = orthogonal * signs[:, None, :]
    directions = fnp.reshape(orthogonal, (blocks * width, width))[:pairs]
    norm_squared = fnp.sum(directions * directions, axis=1, keepdims=True)
    return directions / fnp.sqrt(fnp.maximum(norm_squared, 1e-12))


class Estimator(BaseEstimator):
    """Exact-radius sampling with Haar-stratified antipodal directions."""

    def predict(self, mlp, budget):
        width = mlp.width
        depth = mlp.depth
        biases, has_nonzero_bias = _model_biases(mlp)
        pairs = _pair_count(budget, width, depth)

        if pairs < 1:
            fallback = _diagonal_moments(mlp, biases)
            if fallback.shape == (depth, width) and bool(
                fnp.all(fnp.isfinite(fallback))
            ):
                return fallback
            return fnp.zeros((depth, width), dtype=fnp.float32)

        rng = fnp.random.default_rng(mlp.seed)
        if has_nonzero_bias:
            gaussian = rng.standard_normal((pairs, width), dtype=fnp.float32)
            x = fnp.concatenate([gaussian, -gaussian], axis=0)
            radial_scale = 1.0
        else:
            directions = _orthogonal_directions(rng, pairs, width)
            x = fnp.concatenate([directions, -directions], axis=0)
            radial_scale = _chi_mean(width)

        rows = []
        for layer, weight in enumerate(mlp.weights):
            x = x @ weight
            if biases is not None:
                x = x + biases[layer]
            x = fnp.maximum(x, 0.0)

            if layer == 0:
                if not has_nonzero_bias:
                    x = _calibrate_first_covariance(x, weight, radial_scale)
                else:
                    exact_first = _exact_first_mean(weight, biases[0])
                    sampled_first = fnp.mean(x, axis=0)
                    x = x * (
                        exact_first / fnp.maximum(sampled_first, 1e-12)
                    )
            rows.append(fnp.mean(x, axis=0) * radial_scale)

        prediction = fnp.stack(rows, axis=0)
        if prediction.shape == (depth, width) and bool(
            fnp.all(fnp.isfinite(prediction))
        ):
            return prediction

        fallback = _diagonal_moments(mlp, biases)
        if fallback.shape == (depth, width) and bool(
            fnp.all(fnp.isfinite(fallback))
        ):
            return fallback
        return fnp.zeros((depth, width), dtype=fnp.float32)
