"""Random-shifted tent lattice with antithetic covariance whitening."""

from __future__ import annotations

import flopscope as flops
import flopscope.numpy as fnp
from whestbench import BaseEstimator


_BUDGET_FRACTION = 0.155
_MIN_HALF_SAMPLES = 31
_MAX_HALF_SAMPLES = 500_000
_ARRAY_BYTES_LIMIT = 100 * 1024 * 1024
_WORST_CASE_ITEMSIZE = 8


def _is_prime(value: int) -> bool:
    if value < 2:
        return False
    if value % 2 == 0:
        return value == 2
    divisor = 3
    while divisor * divisor <= value:
        if value % divisor == 0:
            return False
        divisor += 2
    return True


def _prime_factors(value: int):
    factors = []
    divisor = 2
    while divisor * divisor <= value:
        if value % divisor == 0:
            factors.append(divisor)
            while value % divisor == 0:
                value //= divisor
        divisor += 1 if divisor == 2 else 2
    if value > 1:
        factors.append(value)
    return factors


def _smallest_primitive_root(modulus: int) -> int:
    factors = _prime_factors(modulus - 1)
    root = 2
    while any(
        pow(root, (modulus - 1) // factor, modulus) == 1
        for factor in factors
    ):
        root += 1
    return root


def _half_sample_count(budget: int, width: int, depth: int) -> int:
    per_full_sample = depth * (2 * width * width + width) + width * width
    fixed = 9 * width**3 + 2 * (2 * width**3)
    full_count = (int(_BUDGET_FRACTION * budget) - fixed) // max(
        per_full_sample, 1
    )
    max_full_by_bytes = _ARRAY_BYTES_LIMIT // max(
        width * _WORST_CASE_ITEMSIZE, 1
    )
    half_count = int(
        max(
            _MIN_HALF_SAMPLES,
            min(_MAX_HALF_SAMPLES, max_full_by_bytes // 2, full_count // 2),
        )
    )
    while half_count > _MIN_HALF_SAMPLES and not _is_prime(half_count):
        half_count -= 1
    return half_count


def _lattice_generator(modulus: int, width: int):
    root = _smallest_primitive_root(modulus)
    values = []
    value = 1
    for _ in range(width):
        values.append(value)
        value = (value * root) % modulus
    return fnp.array(values, dtype=fnp.int64)


class Estimator(BaseEstimator):
    """Tent-transformed Korobov RQMC with antithetic whitening."""

    def predict(self, mlp, budget):
        width = mlp.width
        depth = mlp.depth
        half_count = _half_sample_count(budget, width, depth)
        rng = fnp.random.default_rng(mlp.seed)

        indices = fnp.arange(half_count, dtype=fnp.int64)[:, None]
        shift = rng.uniform(0.0, 1.0, size=(1, width))
        generator = _lattice_generator(half_count, width)[None, :]
        lattice = ((indices * generator) % half_count) / float(half_count)
        probabilities = (lattice + shift) % 1.0
        probabilities = 1.0 - fnp.abs(2.0 * probabilities - 1.0)
        probabilities = fnp.clip(probabilities, 1e-7, 1.0 - 1e-7)
        u = flops.stats.norm.ppf(probabilities).astype(fnp.float32)

        covariance = (u.T @ u) / float(half_count)
        eigenvalues, eigenvectors = fnp.linalg.eigh(covariance)
        eigenvalues = fnp.maximum(eigenvalues, 1e-6)
        inverse_sqrt = (eigenvectors / fnp.sqrt(eigenvalues)) @ eigenvectors.T
        folded_first_weight = inverse_sqrt @ mlp.weights[0]

        x = fnp.concatenate([u, -u], axis=0)
        x = fnp.maximum(x @ folded_first_weight, 0.0)

        # Antithetic input pairs plus whitening already make the empirical
        # second moment exact.  Affinely calibrate each first-layer marginal
        # to its exact rectified-Gaussian mean while retaining that variance.
        weight_norm_squared = fnp.sum(mlp.weights[0] ** 2, axis=0)
        exact_mean = fnp.sqrt(weight_norm_squared) * flops.stats.norm.pdf(0.0)
        exact_second = 0.5 * weight_norm_squared
        sample_mean = fnp.mean(x, axis=0)
        exact_variance = fnp.maximum(exact_second - exact_mean**2, 1e-12)
        sample_variance = fnp.maximum(exact_second - sample_mean**2, 1e-12)
        scale = fnp.sqrt(exact_variance / sample_variance)
        x = (x - sample_mean) * scale + exact_mean
        for weight in mlp.weights[1:]:
            x = fnp.maximum(x @ weight, 0.0)

        final_mean = fnp.mean(x, axis=0)
        zero_rows = fnp.zeros((depth - 1, width), dtype=fnp.float32)
        return fnp.concatenate([zero_rows, final_mean[None, :]], axis=0)
