"""Analytic Control Linearization estimator for WhestBench."""

from __future__ import annotations

import flopscope as flops
import flopscope.numpy as fnp
from whestbench import BaseEstimator


_TARGET_FRACTION = 0.20
_MAX_SAMPLES = 65536
_MAX_PROBE_BYTES = 64 * 1024 * 1024
_FLOAT32_BYTES = 4
_VAR_EPS = 1e-12
_SHRINK_EPS = 1e-20


def _probe_count(budget, width, depth):
    """Conservatively fit the analytic, control, and sampled forward passes."""
    target = int(_TARGET_FRACTION * budget)
    fixed = 10 * depth * width * width + 13 * width**3 + 32 * depth * width
    per_probe = depth * (2 * width * width + 3 * width) + width * width
    available = target - fixed
    if available <= 0:
        return 0
    count = available // max(per_probe, 1)
    memory_count = _MAX_PROBE_BYTES // max(width * _FLOAT32_BYTES, 1)
    count = int(min(_MAX_SAMPLES, memory_count, count))
    return count - (count % 4)


class Estimator(BaseEstimator):
    """End-to-end Monte Carlo corrected by an analytic affine control."""

    def predict(self, mlp, budget):
        width = mlp.width
        depth = mlp.depth

        # Diagonal Gaussian moment propagation.  The official matrices use
        # row-vector activations, so m @ W is the rows-as-neurons W m formula.
        mean = fnp.zeros((width,), dtype=fnp.float32)
        variance = fnp.ones((width,), dtype=fnp.float32)
        analytic_means = []
        slopes = []

        for weight in mlp.weights:
            mu = mean @ weight
            q = variance @ (weight * weight)
            q_pos = fnp.maximum(q, 0.0)
            sigma = fnp.sqrt(fnp.maximum(q_pos, _VAR_EPS))
            standardized = mu / sigma
            phi = flops.stats.norm.pdf(standardized)
            gain = flops.stats.norm.cdf(standardized)
            next_mean = sigma * phi + mu * gain
            second = (q_pos + mu * mu) * gain + mu * sigma * phi
            next_variance = fnp.maximum(second - next_mean * next_mean, 0.0)

            degenerate = q_pos <= _VAR_EPS
            next_mean = fnp.where(degenerate, fnp.maximum(mu, 0.0), next_mean)
            next_variance = fnp.where(degenerate, 0.0, next_variance)
            gain = fnp.where(degenerate, mu > 0.0, gain)

            analytic_means.append(next_mean)
            slopes.append(gain)
            mean = next_mean
            variance = next_variance

        count = _probe_count(budget, width, depth)
        if count < 4:
            return fnp.stack(analytic_means, axis=0)

        # Two balanced folds share one batched nonlinear forward.  Only their
        # means are retained at each layer.
        half = count // 2
        rng = fnp.random.default_rng(mlp.seed)
        base = count // 2
        random_keys = rng.random((base, width), dtype=fnp.float32)
        strata = fnp.argsort(random_keys, axis=0)
        quantiles = (strata + 0.5) / float(base)
        independent = fnp.asarray(
            flops.stats.norm.ppf(quantiles), dtype=fnp.float32
        )
        quarter = base // 2
        probes = fnp.concatenate(
            [
                independent[:quarter],
                -independent[:quarter],
                independent[quarter:],
                -independent[quarter:],
            ],
            axis=0,
        )
        second_moment = (independent.T @ independent) / float(base)
        eigenvalues, eigenvectors = fnp.linalg.eigh(second_moment)
        eigenvalues = fnp.maximum(eigenvalues, 1e-6)
        inverse_sqrt = (eigenvectors / fnp.sqrt(eigenvalues)) @ eigenvectors.T
        folded_first_weight = inverse_sqrt @ mlp.weights[0]
        fold_input_means = fnp.stack(
            [
                fnp.mean(probes[:half], axis=0) @ inverse_sqrt,
                fnp.mean(probes[half:], axis=0) @ inverse_sqrt,
            ],
            axis=0,
        )
        fold_activation_means = []
        activations = fnp.maximum(probes @ folded_first_weight, 0.0)
        first_sample_mean = fnp.mean(activations, axis=0)
        first_scale = analytic_means[0] / fnp.maximum(first_sample_mean, _VAR_EPS)
        activations = activations * first_scale
        fold_activation_means.append(
            fnp.stack(
                [
                    fnp.mean(activations[:half], axis=0),
                    fnp.mean(activations[half:], axis=0),
                ],
                axis=0,
            )
        )
        for weight in mlp.weights[1:]:
            activations = fnp.maximum(activations @ weight, 0.0)
            fold_activation_means.append(
                fnp.stack(
                    [
                        fnp.mean(activations[:half], axis=0),
                        fnp.mean(activations[half:], axis=0),
                    ],
                    axis=0,
                )
            )

        # Since the control is affine, evaluating it at each fold's input mean
        # is exactly its fold sample mean; no per-probe control pass is needed.
        controls = fold_input_means
        previous_mean = fnp.zeros((width,), dtype=fnp.float32)
        predictions = []
        for layer, weight in enumerate(mlp.weights):
            controls = analytic_means[layer] + (
                (controls - previous_mean) @ weight
            ) * slopes[layer]
            delta_a = fold_activation_means[layer][0] - controls[0]
            delta_b = fold_activation_means[layer][1] - controls[1]
            correction = (delta_a + delta_b) * 0.5

            noise = fnp.sum((delta_a - delta_b) * (delta_a - delta_b)) * 0.25
            signal = fnp.sum(correction * correction)
            alpha = 1.0 - noise / (signal + _SHRINK_EPS)
            alpha = fnp.minimum(fnp.maximum(alpha, 0.0), 1.0)
            corrected = analytic_means[layer] + alpha * correction
            prediction = fnp.where(
                fnp.isfinite(corrected),
                fnp.maximum(corrected, 0.0),
                analytic_means[layer],
            )
            predictions.append(prediction)
            previous_mean = analytic_means[layer]

        return fnp.stack(predictions, axis=0)
