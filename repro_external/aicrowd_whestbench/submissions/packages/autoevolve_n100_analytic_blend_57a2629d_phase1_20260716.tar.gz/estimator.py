from __future__ import annotations

import flopscope.numpy as fnp
from whestbench import BaseEstimator


_BUDGET_FRACTION = 0.097
_GROUPS = 1
_MATCH_LAYERS = 1
_MIN_SAMPLES = 32
_MAX_SAMPLES = 1_000_000
_ARRAY_BYTES_LIMIT = 100 * 1024 * 1024
_WORST_CASE_ITEMSIZE = 8
_ANALYTIC_BLEND = 0.0309
_INV_SQRT_2PI = 0.3989422804014327
_CDF_P = 0.2316419
_CDF_B1 = 0.319381530
_CDF_B2 = -0.356563782
_CDF_B3 = 1.781477937
_CDF_B4 = -1.821255978
_CDF_B5 = 1.330274429
_EPS = 1e-6


def _sample_count(budget: int, width: int, depth: int) -> int:
    per_sample = depth * (2 * width * width + width) + width * width
    fixed = _GROUPS * (9 * width**3 + 2 * (2 * width**3))
    k = (int(_BUDGET_FRACTION * budget) - fixed) // max(per_sample, 1)
    max_k_by_bytes = _ARRAY_BYTES_LIMIT // max(width * _WORST_CASE_ITEMSIZE, 1)
    k = int(max(_MIN_SAMPLES, min(_MAX_SAMPLES, max_k_by_bytes, k)))
    k = k - (k & 1)
    return max(2 * _GROUPS * (width + 1), k - (k % (2 * _GROUPS)))


def _symmetric_inverse_sqrt(covariance):
    eigenvalues, eigenvectors = fnp.linalg.eigh(covariance)
    eigenvalues = fnp.maximum(eigenvalues, _EPS)
    return (eigenvectors / fnp.sqrt(eigenvalues)) @ eigenvectors.T


def _normal_pdf(x):
    return _INV_SQRT_2PI * fnp.exp(-0.5 * x * x)


def _normal_cdf(x):
    ax = fnp.abs(x)
    t = 1.0 / (1.0 + _CDF_P * ax)
    poly = (((((_CDF_B5 * t + _CDF_B4) * t + _CDF_B3) * t + _CDF_B2) * t + _CDF_B1) * t)
    cdf_pos = 1.0 - _normal_pdf(ax) * poly
    return fnp.where(x >= 0.0, cdf_pos, 1.0 - cdf_pos)


def _relu_univariate(mu, var):
    sigma = fnp.sqrt(fnp.maximum(var, _EPS))
    alpha = mu / sigma
    phi = _normal_pdf(alpha)
    Phi = _normal_cdf(alpha)
    mean = sigma * phi + mu * Phi
    second = (var + mu * mu) * Phi + mu * sigma * phi
    relu_var = fnp.maximum(second - mean * mean, _EPS)
    return mean, second, relu_var, Phi


def _analytic_moments(mlp, width):
    eye = fnp.eye(width, dtype=fnp.float32)
    mean = fnp.zeros((width,), dtype=fnp.float32)
    second = eye
    means = []
    variances = []

    for weight in mlp.weights:
        pre_mean = mean @ weight
        pre_second = weight.T @ second @ weight
        pre_var = fnp.maximum(fnp.diag(pre_second) - pre_mean * pre_mean, _EPS)
        mean, relu_second_diag, relu_var, gain = _relu_univariate(pre_mean, pre_var)
        pre_cov = pre_second - pre_mean[:, None] * pre_mean[None, :]
        post_cov = gain[:, None] * pre_cov * gain[None, :]
        post_cov = post_cov * (1.0 - eye) + eye * relu_var[None, :]
        second = post_cov + mean[:, None] * mean[None, :]
        second = second * (1.0 - eye) + eye * relu_second_diag[None, :]
        means.append(mean)
        variances.append(relu_var)

    return means, variances


def _match_diag(x, target_mean, target_var):
    sample_mean = fnp.mean(x, axis=0)
    centered = x - sample_mean
    sample_var = fnp.maximum(fnp.mean(centered * centered, axis=0), _EPS)
    return centered * fnp.sqrt(target_var / sample_var) + target_mean


class Estimator(BaseEstimator):
    def predict(self, mlp, budget):
        width = mlp.width
        depth = mlp.depth
        k = _sample_count(budget, width, depth)
        rng = fnp.random.default_rng(mlp.seed)
        half_per_group = k // (2 * _GROUPS)
        analytic_means, analytic_vars = _analytic_moments(mlp, width)

        first_layer_outputs = []
        for _ in range(_GROUPS):
            u = rng.standard_normal((half_per_group, width), dtype=fnp.float32)
            covariance = (u.T @ u) / float(half_per_group)
            inverse_sqrt = _symmetric_inverse_sqrt(covariance)
            folded_first_weight = inverse_sqrt @ mlp.weights[0]
            xg = fnp.concatenate([u, -u], axis=0)
            first_layer_outputs.append(fnp.maximum(xg @ folded_first_weight, 0.0))

        x = fnp.concatenate(first_layer_outputs, axis=0)
        x = _match_diag(x, analytic_means[0], analytic_vars[0])

        for layer_index, weight in enumerate(mlp.weights[1:], start=1):
            x = fnp.maximum(x @ weight, 0.0)
            if layer_index < _MATCH_LAYERS:
                x = _match_diag(x, analytic_means[layer_index], analytic_vars[layer_index])

        mc_mean = fnp.mean(x, axis=0)
        final_mean = (1.0 - _ANALYTIC_BLEND) * mc_mean + _ANALYTIC_BLEND * analytic_means[-1]

        zero_rows = fnp.zeros((depth - 1, width), dtype=fnp.float32)
        return fnp.concatenate([zero_rows, final_mean[None, :]], axis=0)
