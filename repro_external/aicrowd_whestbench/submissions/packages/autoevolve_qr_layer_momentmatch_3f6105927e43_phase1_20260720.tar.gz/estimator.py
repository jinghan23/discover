from __future__ import annotations

import flopscope as flops
import flopscope.numpy as fnp
from whestbench import BaseEstimator


class Estimator(BaseEstimator):
    def predict(self, mlp, budget):
        width = int(mlp.width)
        depth = int(mlp.depth)
        rng = fnp.random.default_rng(int(mlp.seed))

        per_sample = max(1, depth * (2 * width * width + 4 * width))
        n_samples = max(1024, int((0.09 * float(budget)) / float(per_sample)))
        n_samples = min(n_samples, 8192)
        n_samples = max(2, 2 * (n_samples // 2))

        mu = fnp.zeros(width)
        var = fnp.ones(width)
        diag_rows = []
        diag_vars = []
        for w in mlp.weights:
            mu_pre = w.T @ mu
            var_pre = fnp.maximum((w * w).T @ var, 1e-12)
            sigma = fnp.sqrt(var_pre)
            alpha = mu_pre / sigma
            phi = flops.stats.norm.pdf(alpha)
            cdf = flops.stats.norm.cdf(alpha)
            mu = mu_pre * cdf + sigma * phi
            ez2 = (mu_pre * mu_pre + var_pre) * cdf + mu_pre * sigma * phi
            var = fnp.maximum(ez2 - mu * mu, 0.0)
            diag_rows.append(mu)
            diag_vars.append(var)

        half = n_samples // 2
        base = fnp.asarray(rng.standard_normal((half, width), dtype=fnp.float32))
        x = fnp.concatenate((base, -base), axis=0)
        x = x - fnp.mean(x, axis=0)

        q, _ = fnp.linalg.qr(x, mode="reduced")
        x = q * fnp.sqrt(float(n_samples))

        for i, w in enumerate(mlp.weights[:-1]):
            x = fnp.maximum(x @ w, 0.0)
            if i == 0:
                x_center = x - fnp.mean(x, axis=0)
                x_var = fnp.maximum(fnp.mean(x_center * x_center, axis=0), 1e-12)
                x_match = x_center * fnp.sqrt(fnp.maximum(diag_vars[i], 1e-12) / x_var) + diag_rows[i]
                x = 0.2 * x + 0.8 * x_match
            elif i == 1:
                x_center = x - fnp.mean(x, axis=0)
                x_var = fnp.maximum(fnp.mean(x_center * x_center, axis=0), 1e-12)
                x_match = x_center * fnp.sqrt(fnp.maximum(diag_vars[i], 1e-12) / x_var) + diag_rows[i]
                x = 0.92 * x + 0.08 * x_match

        z = x @ mlp.weights[-1]
        final_mc = fnp.asarray(fnp.mean(fnp.maximum(z, 0.0), axis=0), dtype=fnp.float32)
        z_mu = fnp.mean(z, axis=0)
        z_center = z - z_mu
        z_sigma = fnp.sqrt(fnp.maximum(fnp.mean(z_center * z_center, axis=0), 1e-12))
        z_alpha = z_mu / z_sigma
        fnp.asarray(
            z_mu * flops.stats.norm.cdf(z_alpha) + z_sigma * flops.stats.norm.pdf(z_alpha),
            dtype=fnp.float32,
        )

        diag = fnp.asarray(fnp.stack(diag_rows, axis=0), dtype=fnp.float32)
        final_pred = final_mc
        return fnp.asarray(fnp.concatenate((diag[:-1], final_pred[None, :]), axis=0), dtype=fnp.float32)
