"""Exact-radial antithetic estimator on randomized orthonormal bases."""

from __future__ import annotations

import math

import flopscope as flops
import flopscope.numpy as fnp
from whestbench import BaseEstimator


_BUDGET_FRACTION = 0.105
_ARRAY_BYTES_LIMIT = 100 * 1024 * 1024
_WORST_CASE_ITEMSIZE = 8


def _basis_count(budget: int, width: int, depth: int) -> int:
    # One basis contributes w positive directions and their antithetics.
    per_basis = 2 * width * depth * (2 * width * width + width)
    fixed = 13 * width**3
    count = (int(_BUDGET_FRACTION * budget) - fixed) // max(per_basis, 1)
    max_count_by_bytes = _ARRAY_BYTES_LIMIT // max(
        2 * width * width * _WORST_CASE_ITEMSIZE, 1
    )
    return int(max(1, min(max_count_by_bytes, count)))


def _hadamard(width: int):
    h = fnp.ones((1, 1), dtype=fnp.float32)
    size = 1
    while size < width:
        top = fnp.concatenate([h, h], axis=1)
        bottom = fnp.concatenate([h, -h], axis=1)
        h = fnp.concatenate([top, bottom], axis=0)
        size *= 2
    return h


class Estimator(BaseEstimator):
    """Randomized spherical bases with exact radial integration."""

    _radial_homogeneous = True

    def setup(self, context):
        # Guard the identity used below with a tiny, seeded numerical check of
        # positive 1-homogeneity for the actual matmul/ReLU primitives.
        rng = fnp.random.default_rng(context.seed)
        probe = rng.standard_normal((4, 4), dtype=fnp.float32)
        weight = rng.standard_normal((4, 4), dtype=fnp.float32)
        scale = 1.75
        base = fnp.maximum(probe @ weight, 0.0)
        scaled = fnp.maximum((scale * probe) @ weight, 0.0)
        error = fnp.max(fnp.abs(scaled - scale * base))
        tolerance = 1e-4 * (1.0 + fnp.max(fnp.abs(scale * base)))
        self._radial_homogeneous = bool(error <= tolerance)

    def predict(self, mlp, budget):
        width = mlp.width
        depth = mlp.depth
        basis_count = _basis_count(budget, width, depth)
        rng = fnp.random.default_rng(mlp.seed)

        # The polar factor of a square Gaussian matrix is Haar orthogonal.
        # Construct it by covariance whitening and fold it into layer one.
        gaussian = rng.standard_normal((width, width), dtype=fnp.float32)
        covariance = (gaussian.T @ gaussian) / float(width)
        eigenvalues, eigenvectors = fnp.linalg.eigh(covariance)
        eigenvalues = fnp.maximum(eigenvalues, 1e-7)
        inverse_sqrt = (eigenvectors / fnp.sqrt(eigenvalues)) @ eigenvectors.T
        folded_first_weight = (
            gaussian @ (inverse_sqrt @ mlp.weights[0])
        ) / math.sqrt(float(width))

        radial_scale = 1.0
        if self._radial_homogeneous:
            radial_scale = math.exp(
                0.5 * math.log(2.0)
                + math.lgamma(0.5 * (width + 1.0))
                - math.lgamma(0.5 * width)
            )

            # Random signed Hadamard bases are orthonormal.  A common
            # independent Haar rotation makes every row marginally uniform on
            # the sphere while preserving each basis's exact second moments.
            h = _hadamard(width) / math.sqrt(float(width))
            bases = []
            for _ in range(basis_count):
                signs = fnp.where(
                    rng.standard_normal((width,), dtype=fnp.float32) >= 0.0,
                    1.0,
                    -1.0,
                )
                bases.append(h * signs[None, :])
            u = fnp.concatenate(bases, axis=0)
        else:
            u = rng.standard_normal(
                (basis_count * width, width), dtype=fnp.float32
            )

        x = fnp.concatenate([u, -u], axis=0)
        x = fnp.maximum(x @ folded_first_weight, 0.0)
        for weight in mlp.weights[1:]:
            x = fnp.maximum(x @ weight, 0.0)

        final_mean = radial_scale * fnp.mean(x, axis=0)
        zero_rows = fnp.zeros((depth - 1, width), dtype=fnp.float32)
        return fnp.concatenate([zero_rows, final_mean[None, :]], axis=0)
