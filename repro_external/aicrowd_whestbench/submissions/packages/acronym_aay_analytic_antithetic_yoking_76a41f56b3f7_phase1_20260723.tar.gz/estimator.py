"""Analytic Antithetic Yoking estimator for WhestBench."""

from __future__ import annotations

import flopscope as flops
import flopscope.numpy as fnp
from whestbench import BaseEstimator


_BUDGET_FRACTION = 0.102
_MIN_CROSSFIT_PAIRS = 8
_MAX_PAIRS = 1_000_000
_ARRAY_BYTES_LIMIT = 96 * 1024 * 1024
_WORST_CASE_ITEMSIZE = 8
_EPS = 1e-12


def _pair_count(budget: int, width: int, depth: int) -> int:
    """Choose an even pair count from a conservative AAY FLOP model."""
    allowance = int(_BUDGET_FRACTION * budget)
    # Two analytic matrix-vector products and their elementwise work per layer.
    analytic = depth * (5 * width * width + 30 * width)
    # Precompose the linear shadow, then apply it only once to each pair.
    composition = max(depth - 2, 0) * (2 * width**3 + width * width)
    # Exact forwards, the final analytic control, and pairwise statistics.
    per_pair = depth * (4 * width * width + 12 * width) + 2 * width * width + 40 * width
    available = allowance - analytic - composition
    if available <= 0:
        return 0
    pairs = available // max(per_pair, 1)
    max_pairs_by_bytes = _ARRAY_BYTES_LIMIT // max(3 * width * _WORST_CASE_ITEMSIZE, 1)
    pairs = int(min(_MAX_PAIRS, max_pairs_by_bytes, pairs))
    return pairs - (pairs & 1)


def _analytic_moments(mlp):
    """Diagonal-Gaussian centers, variances, and smoothed ReLU gains."""
    width = mlp.width
    mean = fnp.zeros(width, dtype=fnp.float32)
    variance = fnp.ones(width, dtype=fnp.float32)
    means = []
    gains = []

    for weight in mlp.weights:
        pre_mean = weight.T @ mean
        pre_variance = (weight * weight).T @ variance
        positive_variance = pre_variance > _EPS
        safe_variance = fnp.maximum(pre_variance, _EPS)
        sigma = fnp.sqrt(safe_variance)
        alpha = pre_mean / sigma
        probability = flops.stats.norm.cdf(alpha)
        density = flops.stats.norm.pdf(alpha)

        gaussian_mean = sigma * density + pre_mean * probability
        gaussian_raw2 = (
            (pre_variance + pre_mean * pre_mean) * probability
            + pre_mean * sigma * density
        )
        relu_mean = fnp.maximum(pre_mean, 0.0)
        mean = fnp.where(positive_variance, gaussian_mean, relu_mean)
        variance = fnp.where(
            positive_variance,
            fnp.maximum(gaussian_raw2 - mean * mean, 0.0),
            fnp.zeros_like(pre_variance),
        )
        probability = fnp.where(
            positive_variance,
            probability,
            fnp.where(pre_mean > 0.0, 1.0, 0.0),
        )

        means.append(mean)
        gains.append(probability)

    return means, gains


def _crossfit_mean(observation, control, center, split):
    """Correct each fold using an elementwise coefficient from the other fold."""
    y_a = observation[:split]
    y_b = observation[split:]
    c_a = control[:split]
    c_b = control[split:]

    mean_y_a = fnp.mean(y_a, axis=0)
    mean_y_b = fnp.mean(y_b, axis=0)
    mean_c_a = fnp.mean(c_a, axis=0)
    mean_c_b = fnp.mean(c_b, axis=0)

    dy_a = y_a - mean_y_a
    dy_b = y_b - mean_y_b
    dc_a = c_a - mean_c_a
    dc_b = c_b - mean_c_b
    covariance_a = fnp.mean(dy_a * dc_a, axis=0)
    covariance_b = fnp.mean(dy_b * dc_b, axis=0)
    variance_a = fnp.mean(dc_a * dc_a, axis=0)
    variance_b = fnp.mean(dc_b * dc_b, axis=0)

    beta_a = covariance_a / (1.05 * variance_a + _EPS)
    beta_b = covariance_b / (1.05 * variance_b + _EPS)
    valid_a = (
        (variance_a > _EPS)
        & (covariance_a > 0.0)
        & fnp.isfinite(beta_a)
    )
    valid_b = (
        (variance_b > _EPS)
        & (covariance_b > 0.0)
        & fnp.isfinite(beta_b)
    )
    beta_a = fnp.where(valid_a, fnp.minimum(fnp.maximum(beta_a, 0.0), 1.5), 0.0)
    beta_b = fnp.where(valid_b, fnp.minimum(fnp.maximum(beta_b, 0.0), 1.5), 0.0)

    corrected_a = mean_y_a - beta_b * (mean_c_a - center)
    corrected_b = mean_y_b - beta_a * (mean_c_b - center)
    size_a = split
    size_b = observation.shape[0] - split
    return (size_a * corrected_a + size_b * corrected_b) / float(size_a + size_b)


class Estimator(BaseEstimator):
    """Cross-fitted Analytic Antithetic Yoking (AAY)."""

    def predict(self, mlp, budget):
        width = mlp.width
        depth = mlp.depth
        analytic_means, gains = _analytic_moments(mlp)
        pairs = _pair_count(budget, width, depth)

        if pairs < 1:
            return fnp.stack(analytic_means, axis=0)

        if depth == 1:
            return fnp.stack(analytic_means, axis=0)

        shadow_map = mlp.weights[1] * gains[1]
        for layer in range(2, depth):
            transition = mlp.weights[layer] * gains[layer]
            shadow_map = shadow_map @ transition

        rng = fnp.random.default_rng(mlp.seed)
        orthogonal_pairs = pairs - pairs % width
        if orthogonal_pairs >= 2 * width:
            pairs = orthogonal_pairs
            blocks = pairs // width
            blocks_a = blocks // 2
            blocks_b = blocks - blocks_a
            fold_split = blocks_a * width
            if (width & (width - 1)) == 0:
                basis_draws = rng.standard_normal(
                    (2, width, width), dtype=fnp.float32
                )
                rotations, _ = fnp.linalg.qr(basis_draws)
                hadamard = fnp.array([[1.0]], dtype=fnp.float32)
                hadamard_size = 1
                while hadamard_size < width:
                    upper = fnp.concatenate([hadamard, hadamard], axis=1)
                    lower = fnp.concatenate([hadamard, -hadamard], axis=1)
                    hadamard = fnp.concatenate([upper, lower], axis=0)
                    hadamard_size *= 2
                hadamard = hadamard / fnp.sqrt(float(width))
                direction_blocks = []
                for fold, fold_blocks in ((0, blocks_a), (1, blocks_b)):
                    direction_blocks.append(rotations[fold])
                    for basis_index in range(1, fold_blocks):
                        sign_draws = rng.standard_normal(
                            width, dtype=fnp.float32
                        )
                        signs = fnp.where(sign_draws >= 0.0, 1.0, -1.0)
                        direction_blocks.append(
                            (hadamard * signs) @ rotations[fold]
                        )
                directions = fnp.concatenate(direction_blocks, axis=0)
            else:
                basis_draws = rng.standard_normal(
                    (blocks, width, width), dtype=fnp.float32
                )
                directions, _ = fnp.linalg.qr(basis_draws)
                directions = fnp.reshape(directions, (pairs, width))
            if width & 1:
                radial_steps = fnp.arange(1, width, 2, dtype=fnp.float64)
                mean_radius = fnp.sqrt(2.0 / fnp.pi)
            else:
                radial_steps = fnp.arange(2, width, 2, dtype=fnp.float64)
                mean_radius = fnp.sqrt(fnp.pi / 2.0)
            mean_radius = mean_radius * fnp.prod(
                (radial_steps + 1.0) / radial_steps
            )
            mean_radius = fnp.asarray(mean_radius, dtype=fnp.float32)
            positive_input = fnp.reshape(
                directions * mean_radius, (pairs, width)
            )
        else:
            positive_input = rng.standard_normal((pairs, width), dtype=fnp.float32)
            fold_split = pairs // 2
        trajectories = fnp.concatenate([positive_input, -positive_input], axis=0)
        first_delta = None

        for layer, weight in enumerate(mlp.weights):
            trajectories = fnp.maximum(trajectories @ weight, 0.0)
            if layer == 0:
                observation = 0.5 * (
                    trajectories[:pairs] + trajectories[pairs:]
                )
                first_delta = observation - analytic_means[0]

        observation = 0.5 * (
            trajectories[:pairs] + trajectories[pairs:]
        )
        controls = analytic_means[-1] + first_delta @ shadow_map
        if pairs >= _MIN_CROSSFIT_PAIRS:
            estimate = _crossfit_mean(
                observation, controls, analytic_means[-1], fold_split
            )
        elif pairs == 1:
            estimate = observation[0]
        else:
            estimate = fnp.mean(observation, axis=0) - (
                fnp.mean(controls, axis=0) - analytic_means[-1]
            )

        estimate = fnp.where(
            fnp.isfinite(estimate), estimate, analytic_means[-1]
        )
        final_estimate = fnp.maximum(estimate, 0.0)
        return fnp.stack(analytic_means[:-1] + [final_estimate], axis=0)
