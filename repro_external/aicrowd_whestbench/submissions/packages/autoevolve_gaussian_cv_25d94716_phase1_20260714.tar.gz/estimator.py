from __future__ import annotations

import flopscope.numpy as fnp
import flopscope as flops
from whestbench import BaseEstimator


class Estimator(BaseEstimator):
    def predict(self, mlp, budget):
        width = int(mlp.width)
        depth = int(mlp.depth)
        d_mu = fnp.zeros(width)
        d_var = fnp.ones(width)
        diag_rows = []
        diag_vars = []
        for w in mlp.weights:
            d_mu_pre = w.T @ d_mu
            d_var_pre = (w * w).T @ d_var
            d_var_pre = fnp.maximum(d_var_pre, 1e-12)
            d_sigma = fnp.sqrt(d_var_pre)
            d_alpha = d_mu_pre / d_sigma
            d_phi = flops.stats.norm.pdf(d_alpha)
            d_cdf = flops.stats.norm.cdf(d_alpha)
            d_mu = d_mu_pre * d_cdf + d_sigma * d_phi
            d_ez2 = (d_mu_pre * d_mu_pre + d_var_pre) * d_cdf + d_mu_pre * d_sigma * d_phi
            d_var = fnp.maximum(d_ez2 - d_mu * d_mu, 0.0)
            diag_rows.append(d_mu)
            diag_vars.append(d_var)

        if depth == 1:
            return fnp.asarray(fnp.stack(diag_rows, axis=0), dtype=fnp.float32)

        per_sample = max(1, depth * (2 * width * width + 4 * width))
        n_samples = max(1024, int((0.625 * float(budget)) / float(per_sample)))
        n_samples = min(n_samples, 13744)
        n_samples = 2 * max(1, n_samples // 2)

        rng = fnp.random.default_rng(int(mlp.seed) + 2)
        eye = fnp.eye(width, dtype=fnp.float64)
        half_samples = n_samples // 2
        x0 = fnp.asarray(rng.standard_normal((half_samples, width), dtype=fnp.float32))
        x = fnp.concatenate([x0, -x0], axis=0)

        for i, w in enumerate(mlp.weights[:-1]):
            z = x @ w
            if i == 0:
                t_cov = w.T @ w
                z_center = z - fnp.mean(z, axis=0)
                sample_cov = (z_center.T @ z_center) / float(n_samples)
                s_vals, s_vecs = fnp.linalg.eigh(sample_cov)
                t_vals, t_vecs = fnp.linalg.eigh(t_cov)
                inv_sqrt = s_vecs @ (
                    fnp.diag(1.0 / fnp.sqrt(fnp.maximum(s_vals, 1e-12))) @ s_vecs.T
                )
                target_sqrt = t_vecs @ (
                    fnp.diag(fnp.sqrt(fnp.maximum(t_vals, 1e-12))) @ t_vecs.T
                )
                z = z_center @ (inv_sqrt @ target_sqrt)

            x = fnp.maximum(z, 0.0)
            if i == 0:
                x_mean0 = fnp.mean(x, axis=0)
                x_center = x - x_mean0
                sample_cov = (x_center.T @ x_center) / float(n_samples)
                s_vals, s_vecs = fnp.linalg.eigh(sample_cov)

                sigma0 = fnp.sqrt(fnp.maximum(fnp.diagonal(t_cov), 1e-12))
                scale0 = fnp.maximum(sigma0[:, None] * sigma0[None, :], 1e-12)
                rho0 = fnp.clip(t_cov / scale0, -0.999999, 0.999999)
                root0 = fnp.sqrt(fnp.maximum(1.0 - rho0 * rho0, 0.0))
                pi = 3.141592653589793
                kernel0 = (root0 + (pi - fnp.arccos(rho0)) * rho0) / (2.0 * pi)
                target_second = (sigma0[:, None] * sigma0[None, :]) * kernel0
                target_cov = target_second - diag_rows[0][:, None] * diag_rows[0][None, :]
                target_cov = 0.5 * (target_cov + target_cov.T)
                target_cov = target_cov * (1.0 - eye) + eye * diag_vars[0][None, :]

                t_vals, t_vecs = fnp.linalg.eigh(target_cov)
                inv_sqrt = s_vecs @ (
                    fnp.diag(1.0 / fnp.sqrt(fnp.maximum(s_vals, 1e-12))) @ s_vecs.T
                )
                target_sqrt = t_vecs @ (
                    fnp.diag(fnp.sqrt(fnp.maximum(t_vals, 1e-12))) @ t_vecs.T
                )
                x_full = x_center @ (inv_sqrt @ target_sqrt) + diag_rows[0]
                x = (
                    diag_rows[0]
                    - 0.245 * (x_mean0 - diag_rows[0])
                    + 1.455 * (x_full - diag_rows[0])
                    - 0.455 * x_center
                )

        z = x @ mlp.weights[-1]
        z64 = fnp.asarray(z, dtype=fnp.float64)
        z_mean = fnp.mean(z64, axis=0)
        z_center = z64 - z_mean
        z_var = fnp.mean(z_center * z_center, axis=0)
        z_sigma = fnp.sqrt(fnp.maximum(z_var, 1e-12))
        z_alpha = z_mean / z_sigma
        z_cdf = flops.stats.norm.cdf(z_alpha)
        z_phi = flops.stats.norm.pdf(z_alpha)
        final_gauss = z_mean * z_cdf + z_sigma * z_phi
        z_alpha_md = d_mu_pre / z_sigma
        final_mixed_diag = d_mu_pre * flops.stats.norm.cdf(z_alpha_md) + z_sigma * flops.stats.norm.pdf(z_alpha_md)
        final_mc = fnp.sum(fnp.maximum(z64, 0.0), axis=0) / float(n_samples)
        final = 0.99965 * (
            1.03700 * final_mc
            - 0.0425 * final_gauss
            + 0.00550 * final_mixed_diag
        )

        return fnp.asarray(fnp.stack(list(diag_rows[:-1]) + [final], axis=0), dtype=fnp.float32)
