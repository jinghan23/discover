"""Random-shifted rank-1 RQMC with antithetic covariance whitening."""

from __future__ import annotations

import flopscope as flops
import flopscope.numpy as fnp
from whestbench import BaseEstimator


_BUDGET_FRACTION = 0.13283
_MIN_HALF_SAMPLES = 32
_ARRAY_BYTES_LIMIT = 100 * 1024 * 1024
_WORST_CASE_ITEMSIZE = 8

# Prime lattice sizes avoid collapsed one-dimensional projections for every
# nonzero generating-vector component.  The dense entries around the target
# suite's operating range avoid wasting a meaningful part of the FLOP budget.
_PRIME_SIZES = (
    8191,
    6143,
    5003,
    4931,
    4919,
    4903,
    4273,
    4201,
    4111,
    4093,
    4049,
    3163,
    3137,
    2039,
    1021,
    509,
    251,
    127,
    61,
    31,
)

# Coordinate construction, clipping, and inverse-normal evaluation.  This is
# included in sample allocation in addition to the evaluator's own tracking.
_RQMC_FLOPS_PER_COORD = 45


def _half_sample_count(budget: int, width: int, depth: int) -> int:
    per_full_sample = depth * (2 * width * width + width) + width * width
    per_full_sample += (_RQMC_FLOPS_PER_COORD * width) // 2
    fixed = 9 * width**3 + 2 * (2 * width**3)
    full_count = (int(_BUDGET_FRACTION * budget) - fixed) // max(
        per_full_sample, 1
    )
    byte_limited = _ARRAY_BYTES_LIMIT // max(
        2 * width * _WORST_CASE_ITEMSIZE, 1
    )
    requested = int(max(_MIN_HALF_SAMPLES, min(byte_limited, full_count // 2)))
    for size in _PRIME_SIZES:
        if size <= requested:
            return size
    return _MIN_HALF_SAMPLES


class Estimator(BaseEstimator):
    """Shifted rank-1 Gaussian RQMC, mirrored and empirically whitened."""

    def predict(self, mlp, budget):
        width = mlp.width
        depth = mlp.depth
        n = _half_sample_count(budget, width, depth)
        rng = fnp.random.default_rng(mlp.seed)

        # For prime n, every component in [1, n) produces a permutation of the
        # n equally spaced strata.  A continuous Cranley-Patterson shift makes
        # the lattice randomized while retaining its rank-1 structure.
        # Korobov generating vector using a small multiplier whose orbit is
        # longer than the input dimension at the suite's operating modulus.
        generator = fnp.asarray(
            [float(pow(2, coordinate, n)) for coordinate in range(width)],
            dtype=fnp.float32,
        )[None, :]
        shift = rng.random((1, width), dtype=fnp.float32)
        index = fnp.arange(n, dtype=fnp.float32)[:, None]
        uniform = index * (generator / float(n)) + shift
        uniform = uniform - fnp.floor(uniform)
        uniform = fnp.clip(uniform, 1e-7, 1.0 - 1e-7)
        u = flops.stats.norm.ppf(uniform)

        x = fnp.concatenate([u, -u], axis=0)

        covariance = (u.T @ u) / float(n)
        eigenvalues, eigenvectors = fnp.linalg.eigh(covariance)
        eigenvalues = fnp.maximum(eigenvalues, 1e-6)
        inverse_sqrt = (eigenvectors / fnp.sqrt(eigenvalues)) @ eigenvectors.T
        folded_first_weight = inverse_sqrt @ mlp.weights[0]

        x = fnp.maximum(x @ folded_first_weight, 0.0)

        # Mirroring gives each first-layer pair the activations (|z|, 0), and
        # whitening already fixes E[z^2].  Correct the positive magnitude to
        # the known Gaussian first and second moments before propagation.
        input_variance = fnp.sum(mlp.weights[0] * mlp.weights[0], axis=0)
        target_positive_mean = fnp.sqrt(input_variance) * 0.7978845608028654
        sampled_positive_mean = 2.0 * fnp.mean(x, axis=0)
        target_positive_variance = (
            input_variance - target_positive_mean * target_positive_mean
        )
        sampled_positive_variance = fnp.maximum(
            input_variance
            - sampled_positive_mean * sampled_positive_mean,
            1e-12,
        )
        scale = fnp.sqrt(
            target_positive_variance / sampled_positive_variance
        )
        offset = target_positive_mean - scale * sampled_positive_mean
        adjusted = fnp.maximum(x * scale + offset, 0.0)
        x = fnp.where(x > 0.0, adjusted, 0.0)

        for weight in mlp.weights[1:]:
            x = fnp.maximum(x @ weight, 0.0)

        final_mean = fnp.mean(x, axis=0)
        zero_rows = fnp.zeros((depth - 1, width), dtype=fnp.float32)
        return fnp.concatenate([zero_rows, final_mean[None, :]], axis=0)
