"""Whitened-antithetic lattice Gaussian submission candidate."""

from __future__ import annotations

import flopscope.numpy as fnp
from whestbench import BaseEstimator


_BUDGET_FRACTION = 0.13
_MIN_SAMPLES = 32
_MAX_SAMPLES = 1_000_000
_ARRAY_BYTES_LIMIT = 100 * 1024 * 1024
_WORST_CASE_ITEMSIZE = 8
_TWO_PI = 6.283185307179586


def _sample_count(budget: int, width: int, depth: int) -> int:
    per_sample = depth * (2 * width * width + width) + width * width + 16 * width
    fixed = 9 * width**3 + 2 * (2 * width**3)
    k = (int(_BUDGET_FRACTION * budget) - fixed) // max(per_sample, 1)
    max_k_by_bytes = _ARRAY_BYTES_LIMIT // max(width * _WORST_CASE_ITEMSIZE, 1)
    k = int(max(_MIN_SAMPLES, min(_MAX_SAMPLES, max_k_by_bytes, k)))
    k = k - (k & 1)
    return max(_MIN_SAMPLES, min(k, 6144))


def _lattice_normal(half: int, width: int, seed: int):
    pairs = width // 2
    i = (fnp.arange(half, dtype=fnp.float32) + 0.5)[:, None]
    j = (fnp.arange(pairs, dtype=fnp.float32) + 1.0)[None, :]

    u1 = fnp.mod(i * fnp.sqrt(2.0 * j + 1.0) * 0.754877666 + 0.5, 1.0)
    u2 = fnp.mod(i * fnp.sqrt(2.0 * j + 2.0) * 0.569840291 + 0.5, 1.0)
    u1 = fnp.clip(u1, 1e-7, 1.0 - 1e-7)

    radius = fnp.sqrt(-2.0 * fnp.log(u1))
    angle = _TWO_PI * u2
    z0 = radius * fnp.cos(angle)
    z1 = radius * fnp.sin(angle)
    z = fnp.concatenate([z0, z1], axis=1)
    if width & 1:
        rng = fnp.random.default_rng(seed)
        extra = rng.standard_normal((half, 1), dtype=fnp.float32)
        z = fnp.concatenate([z, extra], axis=1)
    return z


class Estimator(BaseEstimator):
    """Antithetic randomized lattice samples with empirical whitening."""

    def predict(self, mlp, budget):
        width = mlp.width
        depth = mlp.depth
        k = _sample_count(budget, width, depth)
        u = _lattice_normal(k // 2, width, mlp.seed)
        x = fnp.concatenate([u, -u], axis=0)

        covariance = (u.T @ u) / float(k // 2)
        eigenvalues, eigenvectors = fnp.linalg.eigh(covariance)
        eigenvalues = fnp.maximum(eigenvalues, 1e-6)
        inverse_sqrt = (eigenvectors / fnp.sqrt(eigenvalues)) @ eigenvectors.T
        folded_first_weight = inverse_sqrt @ mlp.weights[0]

        x = fnp.maximum(x @ folded_first_weight, 0.0)
        for weight in mlp.weights[1:]:
            x = fnp.maximum(x @ weight, 0.0)

        final_mean = fnp.mean(x, axis=0)
        zero_rows = fnp.zeros((depth - 1, width), dtype=fnp.float32)
        return fnp.concatenate([zero_rows, final_mean[None, :]], axis=0)
