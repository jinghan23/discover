"""RQMC + Rao-Blackwell submission candidate at 70% tracked budget.

Public method description:
https://discourse.aicrowd.com/t/unbiased-randomized-qmc-rao-blackwell-for-post-relu-activation-means-method-unbiasedness-proof-and-where-the-frontier-is/18053
"""

from __future__ import annotations

import flopscope as flops
import flopscope.numpy as fnp
from whestbench import BaseEstimator


_TARGET_FLOP_FRACTION = 0.70
_TAIL_CLIP = 1e-11
_ARRAY_BYTES_LIMIT = 100 * 1024 * 1024
_FLOAT64_ITEMSIZE = 8


def _first_primes(count: int) -> tuple[int, ...]:
    primes: list[int] = []
    candidate = 2
    while len(primes) < count:
        is_prime = True
        for prime in primes:
            if prime * prime > candidate:
                break
            if candidate % prime == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(candidate)
        candidate += 1
    return tuple(primes)


def _lattice_generator(width: int) -> fnp.ndarray:
    roots = fnp.sqrt(fnp.array(_first_primes(width), dtype=fnp.float64))
    return roots - fnp.floor(roots)


def _lattice_uniforms(
    n_samples: int, generator: fnp.ndarray, shift: fnp.ndarray
) -> fnp.ndarray:
    indices = fnp.arange(n_samples, dtype=fnp.float64)[:, None]
    unwrapped = indices * generator[None, :] + shift[None, :]
    return unwrapped - fnp.floor(unwrapped)


def _exact_first_layer_mean(first_weight: fnp.ndarray) -> fnp.ndarray:
    standard_deviation = fnp.sqrt(fnp.sum(first_weight * first_weight, axis=0))
    return standard_deviation / fnp.sqrt(2.0 * fnp.pi)


def _sample_count(budget: int, width: int, depth: int) -> int:
    # Each row pays for the lattice construction and inverse-normal map, every
    # layer's matmul/ReLU, and sampled means for rows 1..depth-1. The first row
    # uses the exact Gaussian ReLU mean instead.
    lattice_per_sample = 89 * width
    forward_per_sample = depth * (2 * width * width + width)
    later_means_per_sample = max(depth - 1, 0) * width
    per_sample = lattice_per_sample + forward_per_sample + later_means_per_sample

    # Fixed work is tiny relative to the forward pass; reserve it explicitly
    # so the phase-1 count remains under the requested tracked-FLOP fraction.
    fixed = 2 * width * width + 8 * width
    n_samples = (int(_TARGET_FLOP_FRACTION * budget) - fixed) // per_sample
    max_samples_by_bytes = _ARRAY_BYTES_LIMIT // max(width * _FLOAT64_ITEMSIZE, 1)
    return int(max(1, min(n_samples, max_samples_by_bytes)))


class Estimator(BaseEstimator):
    """Single-shift rank-1 lattice estimator with an exact first output row."""

    def predict(self, mlp, budget):
        n_samples = _sample_count(budget, mlp.width, mlp.depth)
        rng = fnp.random.default_rng(mlp.seed)
        generator = _lattice_generator(mlp.width)
        shift = rng.random(mlp.width)
        uniforms = _lattice_uniforms(n_samples, generator, shift)
        uniforms = fnp.clip(uniforms, _TAIL_CLIP, 1.0 - _TAIL_CLIP)
        activations = flops.stats.norm.ppf(uniforms)

        rows = []
        for layer_index, weight in enumerate(mlp.weights):
            activations = fnp.maximum(activations @ weight, 0.0)
            if layer_index == 0:
                rows.append(_exact_first_layer_mean(weight))
            else:
                rows.append(fnp.mean(activations, axis=0))
        return fnp.stack(rows, axis=0)
